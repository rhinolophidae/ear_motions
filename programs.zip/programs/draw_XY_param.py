import numpy as np
import matplotlib.pyplot as plt
import time
import datetime
def drawXY_param(X,Y,xX=1,xY=1,Xlab="",Ylab="",title="",mM=False,fname=None,save_data=False,lw=1,xticks=None,yticks=None,figsize=None,scatter=False,ratio=None,arrow=None,arrow_width=0.2):
    """
    draw_XY_param(Y,X=None,xX=1,xY=1,Xlab="",Ylab="",title="",mM=False,fname=None,save_data=False,lw=1,xticks=None,yticks=None,figsize=None,scatter=False,ratio=None,arrow=None)
    
    figsize:[x,y]
    
    --imports--
    
    import numpy as np
    import matplotlib.pyplot as plt
    import time
    import datetime
    
    mM : [minX,maxX,minY,maxY]
    lw : linewidth
    scatter : int(output scatter step)
    arrow : float (drawing arrow from initial-point to second-point !value is length of arrays)
    
    if(fname is None):plt.show()
    else:plt.savefig(fname)
    
    """

    X=np.array(X)
    Y=np.array(Y)
    plt.rcParams["font.size"] = 20

    plot_n=X.shape[0]
    print(X.shape,Y.shape)
    if((X.shape[0]!=Y.shape[0]) or (X.shape[1]!=Y.shape[1])):
        print("error X.shape != Y.shape")
        return
        
    figr=2
    if(figsize is None):figrx,figry=4,3
    else:figrx,figry=figsize
    figx=figrx*figr
    figy=figry*figr
        
    fig=plt.figure(figsize=(figx,figy))
    ax=fig.add_subplot(111)
    
    if(title):fig.suptitle(title,fontsize=24)
    if(mM):
        ax.set_xlim([mM[0]*xX,mM[1]*xX])
        ax.set_ylim([mM[2]*xY,mM[3]*xY])
    if(Xlab):ax.set_xlabel(Xlab,fontsize=20)
    if(Ylab):ax.set_ylabel(Ylab,fontsize=20)
    
    if(not (ratio is None)):ax.set_aspect(ratio)

    if(Y.ndim==1):
        ax.plot(X*xX,Y*xY)

    else:
        for i in range(plot_n):
            ax.plot(X[i]*xX,Y[i]*xY,linewidth=lw)
            

    if(not (arrow is None)):
        if(Y.ndim==1):
            ax.arrow(x=X[0]*xX,y=Y[0]*xY,dx=(X[1]-X[0])*arrow*xX,dy=(Y[1]-Y[0])*arrow*xY,width=arrow_width,fc="k")
        else:
            for i in range(plot_n):
                ax.arrow(x=X[i,0]*xX,y=Y[i,0]*xY,dx=(X[i,1]-X[i,0])*arrow*xX,dy=(Y[i,1]-Y[i,0])*arrow*xY,width=arrow_width,fc="k")            

    if(fname is None):plt.show()
    else:plt.savefig(fname)
    
    if(scatter):
        for h in range(X.shape[1]//(scatter*1)):
            fig=plt.figure(figsize=(figx,figy))
            ax=fig.add_subplot(111)

            if(title):fig.suptitle(title,fontsize=24)
            if(mM):
                ax.set_xlim([mM[0]*xX,mM[1]*xX])
                ax.set_ylim([mM[2]*xY,mM[3]*xY])
            if(Xlab):ax.set_xlabel(Xlab,fontsize=20)
            if(Ylab):ax.set_ylabel(Ylab,fontsize=20)
            
            if(Y.ndim==1):ax.plot(X*xX,Y*xY)
            else:
                for i in range(plot_n):
                    ax.plot(X[i,h*scatter]*xX,Y[i,h*scatter]*xY,marker="o")
                    ax.plot(X[i]*xX,Y[i]*xY,linewidth=lw)
                    
            if(fname is None):plt.show()
            else:
                plt.savefig(fname+"_%04d.png" %(h))
                del fig
                plt.close()
            
    
    if(save_data):
        np.savetxt(out_str+"_X.txt",X)
        np.savetxt(out_str+"_Y.txt",Y)
    
#print(drawXY_param.__doc__)
