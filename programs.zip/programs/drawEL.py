import numpy as np
from numpy import pi,sin,cos
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import sys
import time
from matplotlib.colors import Normalize # Normalizeをimport colorbarの範囲指定
from mpl_toolkits.mplot3d import axes3d, Axes3D #3Dプロット用

import datetime
from draw_XY import drawXY
from draw_XY_param import drawXY_param
from draw_XYZ import drawXYZ
from colormap_matrix import CM
from rot_mat import Rot
from rot_mat import Rot2d

from calc_ears import calc_thes,calc_phes,calc_pses

from scipy.spatial import ConvexHull

from plus_minus import pm
from rtp2xyz import r2x_3
from draw_gosa import draw_gosa2d



import codecs #printでファイル出力するため


basedir="output_data/output_LE/"
outdir=basedir+"evaluate/"

e=1e-11
r2d=180/pi #rad2deg and deg2rad
d2r=pi/180

f_emit=70100#70100
f_ear=15
c=340.0
wave_l=c/f_emit
Amp=0.25

tp_range=60.1*d2r

dy=0.5*0.999999999
dz=0.5*0.999999999

Amp_sigmas=np.array([0.0])

timeMax=1/f_ear
timeBunkatsu=66*1#300
Delta_t=timeMax/timeBunkatsu

bat_d=0.012
bat_dy=dy*wave_l
bat_dz=dz*wave_l #後で設定

Times=np.arange(0,timeMax,Delta_t)

obs_rRange=[1.0,5.0]
search_tp=60.0*d2r
search_theta=search_tp
search_phi=search_tp



#bat_k1=bat_d/2
#bat_k2=bat_dz/2
#bat_k3=bat_dy/2

obs_thetaRange=[-search_theta,search_theta]
obs_phiRange=[-search_phi,search_phi]


def npdots(A):
    n=np.array(A).shape[0]
    ret=A[0]
    for i in range(n-1):
        ret=np.dot(ret,A[i+1])
    return ret


def nar(x):
    return np.array(x)



















#学習結果と評価関数計算の統合データ作成
from importlib import reload
from draw_XYZ_20210922 import drawXYZ
reload(sys.modules["draw_XYZ_20210922"])
from draw_XYZ_20210922 import drawXYZ

fndw1=basedir+"learn/"
fndw2=basedir+"evaluate/"
outdir=basedir
outdir_3dline=basedir+"3d_line/"

ntph=131#131
dAs=[0,1,3]

temp=[10,11,12,13,14,15]

i_s=temp
js=[14]
ks=temp

ijks=[]
for i in i_s:
    for j in js:
        for k in ks:
            ijks.append([i,j,k])
#ijks=[[11,14,12],[11,107,107],[11,108,108],[11,15,13]]
ijks=nar(ijks)

print(ijks.shape,ijks)

tps=np.linspace(-tp_range,tp_range,ntph)
s2=0.38

for dA in dAs:

    fno=outdir+f"0learn_evaluate_dA={dA}_is={i_s}_js={js}_ks={ks}_100s2={int(s2*100+0.001)}.csv"
    fo=open(fno,"w")
    fo.write("psi_i,phi_j,theta_k,mean_dy,max_dy,int_evaluate,int_Ecosphi,max_evaluate,dimL,dim,vL,v,dimsub,I(M),E(M)deg,\n")

    for i in i_s:
        for j in js:
            for k in ks:

                check_ijk=False
                for ijk in ijks:
                    if(np.all([i,j,k]==ijk)):check_ijk=True
                print(check_ijk)
                if(not check_ijk):continue
                mode=nar([i,j,k])

                psel,pser=calc_pses(times=Times,mode=mode[0])
                phel,pher=calc_phes(times=Times,mode=mode[1])
                thel,ther=calc_thes(times=Times,mode=mode[2])

                m=mode
                fndw=outdir_3dline+"000_3dLine_mode=[{},{},{}]".format(m[0],m[1],m[2])

                pts=[]
                for t in range(Times.size):
                    pts.append([psel[t],phel[t],thel[t]])
                dimL=np.linalg.matrix_rank(pts)
                if(dimL==3):
                    print("\n-----dimL=3-----",mode)
                    try:
                        vL=ConvexHull(pts).volume
                    except:
                        vL=-100
                else:
                    vL=0

                for t in range(Times.size):
                    pts.append([pser[t],pher[t],ther[t]])
                pts=nar(pts)
                dim=np.linalg.matrix_rank(pts)
                if(dim==3):
                    v=ConvexHull(pts).volume

                    #何故か次元が合わないので修正。あとから目視で正しいことを確認
                    if(v>0.1 and vL==-100):
                        dimL=2
                        vL=0
                    elif(0.04<v<0.05):
                        dimL=1

                else:
                    v=0


                data=np.load(fndw1+f"mode=[{i},{j},{k}]_dA={dA}_dy=0.0024251069875891582_dz=0.0024251069875891582__dyst.npy")

                nph=int(np.sqrt(data.shape[1]+0.01))
                nph2=nph**2
                nt=int(data.shape[0]+0.01)

                mth=np.zeros(nph2)
                mph=np.zeros(nph2)
                for ij in range(nph2):
                    mth[ij]=np.median(data[:,ij,0],axis=0)
                    mph[ij]=np.median(data[:,ij,1],axis=0)
                mtph=np.abs(mth)+np.abs(mph)

                dataabs=np.abs(data)
                dyabs=np.sum(dataabs)/(data.shape[0]*data.shape[1])
                L=np.sum(dataabs)/(data.shape[0]*data.shape[1])
                Lmax=np.max(mtph)
                print(L,Lmax)

                DAM=(mtph.reshape((23,23))).T
                DAMDangle=np.zeros_like(DAM)
                for phii in range(23):
                    for thetai in range(23):
                        ex=nar([1,0,0])
                        u=r2x_3(nar([1,tps[thetai],tps[phii]]))
                        naiseki=np.dot(ex,u)
                        nasukaku=np.arccos(naiseki)

                U1=np.loadtxt(fndw2+"mode=[{},{},{}]_nth=nph={}_U1.txt".format(i,j,k,ntph))
                print(U1.shape)
                nph=U1.shape[0]

                E=np.sum(U1)*((2*tp_range/ntph)**2)

                U1cosphi=np.zeros_like(U1) #U1の行にcos(phi)を掛ける。（球面上での積分用）
                cosphis=np.cos(np.linspace(-np.pi/3,np.pi/3,nph))

                Ecosphi=np.zeros_like(U1)
                for phii in range(nph):
                    Ecosphi[phii]=U1[phii]*cosphis[phii]
                intEcosphi=np.sum(Ecosphi)*((2*tp_range/ntph)**2)


                Edangle=np.zeros_like(U1)
                for phii in range(nph):
                    for thetai in range(nph):
                        ex=nar([1,0,0])
                        u=r2x_3(nar([1,tps[thetai],tps[phii]]))
                        naiseki=np.dot(ex,u)
                        nasukaku=np.arccos(naiseki)

                Emax=np.max(U1)
                print(U1.shape,E)


                sublr_ps=psel-pser
                sublr_ph=phel-pher
                sublr_th=thel-ther

                pts=[]
                for ti in range(Times.size):
                    pts.append([sublr_ps[ti],sublr_ph[ti],sublr_th[ti]])
                pts=nar(pts)

                try:
                    v=ConvexHull(pts).volume
                    dim_sub=3
                except:
                    dim_sub=np.linalg.matrix_rank(pts)


                fo.write(f"{i},{j},{k},{L},{Lmax},{E},{intEcosphi},{Emax},{dimL},{dim},{vL},{v},{dim_sub},{1/intEcosphi},{Lmax*r2d},\n")
    fo.close()

print("OK")










#評価関数のカラーマップ生成
from importlib import reload
from draw_XYZ_20210922 import drawXYZ
reload(sys.modules["draw_XYZ_20210922"])
from draw_XYZ_20210922 import drawXYZ

from colormap_matrix_20210906 import CM
from importlib import reload
reload(sys.modules["colormap_matrix_20210906"])
from colormap_matrix_20210906 import CM



#fn_learn_evaluate_csv=basedir+"0learn_evaluate_dA=0_is=[10, 11, 12, 13, 14, 15]_js=[14]_ks=[10, 11, 12, 13, 14, 15]_100s2=38.csv"
fn_learn_evaluate_csv=basedir+"0learn_evaluate_dA=0_is=[10, 11, 12, 13, 14, 15]_js=[10, 11, 12, 13, 14, 15]_ks=[10, 11, 12, 13, 14, 15]_100s2=38.csv"
try:
    data_pd = pd.read_csv(fn_learn_evaluate_csv)
    read_learn_evaluate_csv=True
    data_str=np.array(data_pd.columns)
    print(data_str)
    data=np.array(data_pd)
    print("data.shape=",data.shape)
except:
    read_learn_evaluate_csv=False

print(read_learn_evaluate_csv)


indir=basedir+"evaluate/"
outdir=basedir+"evaluate/"

ntph=131#131
U1=0

def draw_U1(mode):

    M=3

    m=mode
    nth=nph=ntph

    mode_str=[i for i in range(1000)]
    mode_str[10:16]=['0',r"$\overline{\rm CONST}$",r"$\overline{\rm SIN}$","SIN",r"$\overline{\rm COS}$",'COS']
    ms=mode_str

    ph=np.linspace(-tp_range,tp_range,nph)
    dph=ph[1]-ph[0]
    th=np.linspace(-tp_range,tp_range,nth)
    dth=th[1]-th[0]



    psel,pser=calc_pses(times=Times,mode=mode[0])
    phel,pher=calc_phes(times=Times,mode=mode[1])
    thel,ther=calc_thes(times=Times,mode=mode[2])

    pts=[]
    for i in range(Times.size):
        pts.append([psel[i],phel[i],thel[i]])
        pts.append([pser[i],pher[i],ther[i]])
    pts=nar(pts)
    print(pts.shape)
    dim=np.linalg.matrix_rank(pts)
    if(dim==3):
        print("dim=3")
        v=ConvexHull(pts).volume
    else:
        print("dim<3")
        v=0
    print(mode,dim,v)

    drU1=U1.reshape((nth,-1))


    ticks=[-60,-30,0,30,60]
    #fn=outdir+"mode=[{},{},{}]_[{},{},{}]".format(m[0],m[1],m[2],ms[m[0]],ms[m[1]],ms[m[2]])+"_nth=nph={}_M={}".format(ntph,M)+ "_U1"
    #CM(U1.reshape((nth,-1)),X=th*r2d,Y=ph*r2d,mM=[0,M],fname=fn+"_color.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1)
    #CM(U1.reshape((nth,-1)),X=th*r2d,Y=ph*r2d,mM=[0,M],title="[{},{},{}]  V={}".format(ms[m[0]],ms[m[1]],ms[m[2]],v),fname=fn+"_color2.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1)
    #CM(U1.reshape((nth,-1)),X=th*r2d,Y=ph*r2d,mM=[0,M],title="[{},{},{}]  dim={}".format(ms[m[0]],ms[m[1]],ms[m[2]],dim),fname=fn+"_color3.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1)
    #CM(U1.reshape((nth,-1)),X=th*r2d,Y=ph*r2d,mM=[0,M],Xlab=r"$\theta$[deg]",Ylab=r"$\varphi$[deg]",fname=fn+"_color4.png",cmap="coolwarm",left=0.3,xticks=ticks,yticks=ticks,drawr=1)
    fn=outdir+"mode=[{},{},{}]".format(m[0],m[1],m[2])+"_nth=nph={}_M={}".format(ntph,M)+ "_U1"

    #CM(U1.reshape((nth,-1)),X=th*r2d,Y=ph*r2d,mM=[0,M],title="[{},{},{}]  dim={}".format(ms[m[0]],ms[m[1]],ms[m[2]],dim),fname=fn+"_color5.png",cmap="coolwarm",drawcbar=False,xticks=ticks,yticks=ticks,drawr=1)
    #CM(U1.reshape((nth,-1)),X=th*r2d,Y=ph*r2d,mM=[0,M],title="dim={}".format(dim),titlesize=34,fname=fn+"_color6.png",cmap="coolwarm",drawcbar=False,xticks=ticks,yticks=ticks,drawr=1)
    #CM(U1.reshape((nth,-1)),X=th*r2d,Y=ph*r2d,mM=[0,M],title="[{},{},{}]".format(ms[m[0]],ms[m[1]],ms[m[2]]),fname=fn+"_color7.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)
    CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title="[{},{},{}] dim={}".format(ms[m[0]],ms[m[1]],ms[m[2]],dim),fname=fn+"_color8.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)
    CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],fname=fn+"_color9.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)
    CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title=fr"[$\psi_e$: {ms[m[0]]},  $\varphi_e$: {ms[m[1]]},  $\theta_e$: {ms[m[2]]}]  dim={dim}",titlesize=14,fname=fn+"_color12.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)

    datai=-1
    if(read_learn_evaluate_csv):
        for i in range(data.shape[0]):
            x=int(data[i,0]+0.001)
            y=int(data[i,1]+0.001)
            z=int(data[i,2]+0.001)
            print(x,m[0],y,m[1],z,m[2])
            if(x==m[0] and y==m[1] and z==m[2]):
                datai=i
                break
    if(datai>=0):
        x=1/data[datai,6]
        x_=np.round(x, decimals=2)
        print("I(F)=",x)
        #CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title=f"dim={dim}, I[M]={x_}",titlesize=18,fname=fn+"_color10.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1)
        #CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title=f"dim={dim}, I[M]={x_}",titlesize=26,fname=fn+"_color11.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)
        #CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title=f"dim={dim}, I[M]={x_}",titlesize=18,fname=fn+"_color14.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)
        if(x>0.01):
            CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title=f"dim={dim}, I[M]={x_}",titlesize=26,fname=fn+"_color13.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)
        else:
            CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title=f"dim={dim}, I[M]<0.01",titlesize=26,fname=fn+"_color13.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)
            CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title=f"dim={dim}, I[M]<0.01",titlesize=18,fname=fn+"_color14.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)


        x_=0.0
        for i in range(4):
            temp=x*(10**i)
            if(temp>1):
                x_=np.round(temp*10+0.0001)/(10**(i+1))
                break

        CM(drU1,X=th*r2d,Y=ph*r2d,mM=[0,M],title=fr"$I[M]$={x_}",titlesize=26,fname=fn+"_color15.png",cmap="coolwarm",xticks=ticks,yticks=ticks,drawr=1,drawcbar=False)



temp=[10,11,12,13,14,15]

i_s=temp
js=[14]
ks=temp

for i in i_s:
    for j in js:
        for k in ks:
            #if(j!=k):continue
            #if( (i==10 and j==10) or (j==10 and k==10) or (k==10 and i==10)):continue

            mode=np.array([i,j,k])
            print("mode=",mode)

            time_now=datetime.datetime.now()
            #fn=indir+"mode=[{},{},{}]_nth=nph={}_U1.txt".format(i,j,k,ntph)

            fn=indir+"mode=[{},{},{}]_nth=nph={}_U1.txt".format(i,j,k,ntph)
            #print("fn=",fn)

            U1=np.loadtxt(fn)

            draw_U1(mode=mode)

print("OK_drawE")







#学習結果の図を生成
outdir=basedir+"learn/"

def draw_boxplot2d(ts,ys,fname=None,sigma=0.0,draw_rectangle=True):

    #print("ys.shape,ts.shape=\n",ys.shape,ts.shape)

    nx=(int)(np.sqrt(ts.shape[0]+1e-5))


    ysd=ys.copy()
    ysi=ysd!=np.inf
    ysd=ysd[ysi]

    ysd=ysd.reshape((-1,nx*nx,2))
    #print("ysd",ysd.shape,ysd)
    m1=np.percentile(ysd,25,axis=0)
    m2=np.percentile(ysd,50,axis=0)
    m3=np.percentile(ysd,75,axis=0)
    iqr=m3-m1

    #print("iqr",iqr)
    #print("m2",m2,m2.shape)

    cmap=plt.get_cmap("tab10")
    plt.rcParams["font.size"] = 48
    figx,figy=12,12
    fig=plt.figure(figsize=(figx,figy))

    ax=fig.add_subplot(111)

    for i in range(nx):
        for j in range(nx):
            kd=i*nx+j

            xm,ym=m1[kd]+ts[kd]
            x_,y_=m2[kd]+ts[kd]
            xM,yM=m3[kd]+ts[kd]


            #Xs=np.array([X,X])
            #Ys=np.array([ym-1.5*iqry,yM+1.5*iqry])
            #ax.plot(xs,ys,linewidth=1,color="k",ls="-")


            if(draw_rectangle):
                e=patches.Rectangle(xy=(xm,ym),height=yM-ym,width=xM-xm,ec="k",fc="w",fill=False)
                ax.add_patch(e)

            ax.scatter(x=ts[:,0],y=ts[:,1],s=90,marker="x",c="b")
            #ax.scatter(x=m2[:,0],y=m2[:,1],s=90,marker="+",c="r")
            ax.scatter(x=x_,y=y_,s=90,marker="+",c="r")
            #print("iqr[kd]",iqr[kd],iqrx,iqry)
            ax.plot([x_,ts[kd,0]],[y_,ts[kd,1]],color="k",linewidth=3)

            #print("X=",xs)
            #print("Y=",ys)

    ticks=np.array([-60,-30,0,30,60])
    ax.set_xticks(ticks)
    ax.set_xticklabels(ticks)
    ax.set_yticks(ticks)
    ax.set_yticklabels(ticks)

    ax.set_xlim(-search_tp*r2d*1.1,search_tp*r2d*1.1)
    ax.set_ylim(-search_tp*r2d*1.1,search_tp*r2d*1.1)
    #ax.set_xlabel(r"$\theta$[deg]")
    #ax.set_ylabel(r"$\varphi$[deg]")


    plt.subplots_adjust(left=0.05, right=0.95, bottom=0.05, top=0.95)
    plt.tight_layout()
    if(not (fname is None)):plt.savefig(fname)
    plt.close()

temp=[10,11,12,13,14,15]
i_s=temp
js=[14]
ks=temp

dA=0
for i in  i_s:
    for j in js:
        for k in ks:

            fndw=outdir+ "mode=[{},{},{}]_dA={}_dy=0.0024251069875891582_dz=0.0024251069875891582_".format(i,j,k,dA)
            dy_ts2=np.load(fndw+"_dyst.npy")

            print(dy_ts2.shape,i,j,k)
            nx=int(np.sqrt(dy_ts2.shape[1]+0.01))

            x=np.linspace(-search_tp,search_tp,nx)#-60,60
            randmode=False
            dx=2*(search_tp)*randmode/nx
            Xc=np.array([[x[i],x[j]] for i in range(nx) for j in range(nx)])
            obs_tp=Xc

            draw_boxplot2d(ys=dy_ts2*r2d,ts=obs_tp*r2d,fname=fndw+"_boxplot_test.png")
            draw_boxplot2d(ys=dy_ts2*r2d,ts=obs_tp*r2d,fname=fndw+"_boxplot_test2.png",draw_rectangle=False)

print("OK_drawL")



import datetime
print(datetime.datetime.now())
print("ok")
