import numpy as np
import matplotlib.pyplot as plt
import time
import datetime
def drawXY(Y,X=None,xX=1,xY=1,Xlab="",Ylab="",title="",M=False,m=False,Mx=False,mx=False,fname=None,save_data=False,lw=1,xticks="no",yticks="no",out_str="./",figsize=None,ab=0,al=0,legend_label=None,fs=16,draw=True):
    """
    draw_XY(Y,X=None,xX=1,xY=1,Xlab="",Ylab="",title="",M=False,m=False,Mx=False,mx=False,fname=None,save_data=False,lw=1,xticks=None,yticks=None,figsize=None)

    figsize:[x,y]

    --imports--

    import numpy as np
    import matplotlib.pyplot as plt
    import time
    import datetime

    lw : linewidth

    if(fname is None):plt.show()
    else:plt.savefig(fname)

    """
    Y=np.array(Y)
    plt.rcParams["font.size"] = fs
    if(X is None):
        if(Y.ndim==1):
            X=np.arange(Y.size)
        else:
            plot_n=Y.shape[0]
            X=np.arange(Y.shape[1])
    else:
        X=np.array(X)
        plot_n=Y.shape[0]

    print(X.shape,Y.shape)
    figr=2
    if(figsize is None):figrx,figry=4,3
    else:figrx,figry=figsize
    figx=figrx*figr
    figy=figry*figr
    fig=plt.figure(figsize=(figx,figy))
    ax=fig.add_subplot(111)

    if(title):fig.suptitle(title,fontsize=24)
    if(M or m):ax.set_ylim([m*xY,M*xY])
    if(Mx or mx):ax.set_xlim([mx*xX,Mx*xX])

    if(Xlab):ax.set_xlabel(Xlab,fontsize=20)
    if(Ylab):ax.set_ylabel(Ylab,fontsize=20)

    if(xticks != "no"):
        ax.set_xticks(xticks)
        ax.set_xticklabels(xticks)

    if(yticks != "no"):
        ax.set_yticks(yticks)
        ax.set_yticklabels(yticks)

    if(Y.ndim==1):
        ax.plot(X*xX,Y*xY,linewidth=lw)
    else:
        for i in range(plot_n):
            ax.plot(X*xX,Y[i]*xY,linewidth=lw)

    if(al and ab):fig.subplots_adjust(left=al,bottom=ab)
    elif(al):fig.subplots_adjust(left=al)
    elif(ab):fig.subplots_adjust(bottom=ab)


    if(fname is None):plt.show()
    else:plt.savefig(fname)

    if(save_data):
        np.savetxt(out_str+"_X.txt",X)
        np.savetxt(out_str+"_Y.txt",Y)

#print(drawXY.__doc__)
