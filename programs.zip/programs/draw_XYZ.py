import numpy as np
import matplotlib.pyplot as plt
import time
import datetime
from mpl_toolkits.mplot3d import Axes3D
import mpl_toolkits.mplot3d.art3d as art3d

def drawXYZ(X,Y,Z,mode="naname",outdir="./",fname=None,save_data=False,mM=None,scatter=False,drawPolygon=False):
    """
    ------------------------------
    drawXYZ(X,Y,Z,mode="naname",outdir="./",fname=None,save_data=False)

    mode: camera_from[elevation,azimuth]
          "front" =[0,0]
          "back"  =[0,180]
          "top"   =[89,180]
          "naname"=[45,135]

    mM: [minX,maxX,minY,maxY,minZ,maxZ]
    scatter: bool (draw scatter or not)
    --imports--

    import numpy as np
    import matplotlib.pyplot as plt
    import time
    import datetime
    from mpl_toolkits.mplot3d import Axes3D
    ------------------------------
    """

    X=np.array(X)
    Y=np.array(Y)
    Z=np.array(Z)

    plt.rcParams["font.size"] = 14
    cmap=plt.get_cmap("tab10")

    time_now=datetime.datetime.now()
    if(X.ndim==1 or scatter):
        nh=1
        shape=False
    else:
        nh=X.shape[1]
        shape=True
    keta=int(np.floor(np.log10(nh-0.5))+1)
    #ax.scatter(X,Y,Z,marker="o",ms=18,color=cmap(0))
    for h in range(nh):
        fig=plt.figure(figsize=(8,8))
        #fig.subplots_adjust(bottom=0.2)
        #ax=Axes3D(fig)
        ax = fig.add_subplot(111, projection='3d')
        if(mode=="naname"):ele,azi=45,135
        elif(mode=="front"):ele,azi=0,0
        elif(mode=="back"):ele,azi=0,180
        elif(mode=="top"):ele,azi=89,180
        else:ele,azi=mode[0],mode[1]
        ax.view_init(elev=ele,azim=azi)

        #ax.set_aspect('equal')

        if(not (mM is None)):
            ax.set_xlim(mM[0],mM[1])
            ax.set_ylim(mM[2],mM[3])
            ax.set_zlim(mM[4],mM[5])

        ax.set_xlabel("x",fontsize=28)
        ax.set_ylabel("y",fontsize=28)
        ax.set_zlabel("z",fontsize=28)
        if(shape):
            for i in range(X.shape[0]):
                if(drawPolygon):
                    x = X[i]
                    y = Y[i]
                    z = Z[i]
                    poly = list(zip(x,y,z))
                    ax.add_collection3d(art3d.Poly3DCollection([poly],color='m'))
                ax.plot(X[i],Y[i],Z[i],color=cmap(i))

            ax.scatter(X[:,h],Y[:,h],Z[:,h],c="r",alpha=1)
        else:ax.plot(X,Y,Z)

        plt.tight_layout()


        if(fname is None):plt.show()
        else:
            out_str="_"+str(ele) +"," + str(azi) +"_" + str(h).zfill(keta) +  ".png"
            plt.savefig(outdir+fname+out_str)

        if(save_data):
            np.savetxt(out_str+"_X.txt",X)
            np.savetxt(out_str+"_Y.txt",Y)

        del fig
