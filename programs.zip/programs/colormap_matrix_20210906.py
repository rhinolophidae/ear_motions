import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize # Normalizeをimport colorbarの範囲指定
def CM(data,X=None,Y=None,Xlab="",Ylab="",title="",titlesize=16,xticks="no",yticks="no",mM=False,fname=None,show=True,cmap="jet",left=None,right=None,top=None,bottom=None,drawcbar=True,drawr=None):
    """
    CM(data,X="no",Y="no",mM=False,fname="./out.png",output=0)

    --imports--

    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize # Normalizeをimport (set range colorbar)


    data:np.array(2d)
    X,Y:np.array(set of x,y)
    Xlab,Ylab:set_xlabel ylabel
    mM:[m,M] m,M:float (min,Max)
    fname:filename when output
    show: run plt.show() or not
    """
    #output: 0=> plt.show  1=> savefig  2=> both
    plt.rcParams["font.size"]=16#14
    fig=plt.figure(figsize=(4,4))
    ax=fig.add_subplot(111)
    if(not (drawr is None)):ax.set_aspect(drawr)
    if(title):fig.suptitle(title,fontsize=titlesize)

    if(xticks != "no"):
        ax.set_xticks(xticks)
        ax.set_xticklabels(xticks)
    if(yticks != "no"):
        ax.set_yticks(yticks)
        ax.set_yticklabels(yticks)
    #ax.set_xticks([-60,-30,0,30,60])
    #ax.set_xticklabels(["-60","-30","0","30","60"])
    #ax.set_yticks([-60,-30,0,30,60])
    #ax.set_yticklabels(["-60","-30","0","30","60"])


    if((X is None) and (Y is None)):
        X, Y = np.mgrid[:data.shape[0]+1, :data.shape[1]+1]
        #print(X)
    if(X is None):X=np.array([np.arange(data.shape[0]+1)])
    if(Y is None):Y=np.array([np.arange(data.shape[1]+1)])
    if(Xlab):ax.set_xlabel(Xlab,fontsize=18)
    if(Ylab):ax.set_ylabel(Ylab,fontsize=18)
    if(mM):
        m=mM[0]
        M=mM[1]
    else:
        m=np.min(data)
        M=np.max(data)

    cbar=ax.pcolormesh(X,Y,data,cmap=cmap,norm=Normalize(vmin=m,vmax=M))
    if(drawcbar):fig.colorbar(cbar, ax=ax)

    fig.subplots_adjust(left=left,right=right,top=top,bottom=bottom)
    if(fname is None):
        a=0
        #plt.show()
    else:
        plt.savefig(fname)
        #if(show):plt.show()
        plt.close()
#print(CM.__doc__)
