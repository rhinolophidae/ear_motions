import tensorflow as tf
import numpy as np
from numpy import pi,sin,cos
#import matplotlib.pyplot as plt
#from tensorflow.python.framework import ops

import pandas as pd
import sys
import time
from scipy.stats import norm
#from matplotlib.colors import Normalize # Normalizeをimport colorbarの範囲指定
#from mpl_toolkits.mplot3d import axes3d, Axes3D #3Dプロット用
#import scipy.signal as signal

import time
import datetime
#from draw_XYZ import drawXYZ
#from colormap_matrix import CM
from rot_mat import Rot
#from plus_minus import pm
from rtp2xyz import r2x_3

#from draw_gosa import draw_gosa2d
#from draw_XY import drawXY
#from draw_XY_param import drawXY_param
from calc_ears import calc_thes, calc_phes, calc_pses



import time
import fcntl

#import codecs #printでファイル出力するため

basedir="output_data/output_LE/"
outdir=basedir+"learn/"

memo=0
xAngle=1

f_emit=70100#70100
f_ear=15
c=340.0
wave_l=c/f_emit
Amp=0.25
noise_mode=1 #0si:まとめてSにノイズ乗せ 1:1ステップごとにノイズ乗せgmas=np.array(Amp_sigmas)

dys=[0.5*0.999999999]#[0.46]
dzs=[0.5*0.999999999]#[0.48]#[0.2,0.5,1.0]#[0.2,0.4,0.5,0.6,0.8,1.0]

Amp_sigmas=np.array([0.0])

timeMax=1/f_ear
Bun_step=1
timeBunkatsu=66#300
#OmegaEar=4/9*np.pi*10
Delta_t=timeMax/timeBunkatsu

phie0s=[5,10,15,20,25,30,35,40,45]#[18]
thetae0s=[5,10,15,20,25,30,35,40,45]#[15]


bat_d=0.012
bat_dy=dys[0]*wave_l
bat_dz=dzs[0]*wave_l #後で設定
print("bat_dy,dz=",bat_dy,bat_dz)

print("Delta_t=",Delta_t)

Times=np.arange(0,timeMax,Delta_t)

max_epoch=2000
max_step=5000 #5000
out_n_step=250 #250
out_step=max_step-out_n_step

n_in=Times.size
n_mid1=100
n_mid2=50
n_mid3=10
n_out=2
r2d=180/np.pi #rad2deg and deg2rad
d2r=np.pi/180

obs_rRange=[1.0,5.0]
search_tp=60.0*d2r



bat_k1=bat_d/2
bat_k2=bat_dz/2
bat_k3=bat_dy/2



# Define Variable Functions (weights and bias)
def init_weight(shape, st_dev):
    weight = tf.Variable(tf.random_normal(shape, stddev=st_dev))
    return(weight)
def init_bias(shape, st_dev):
    bias = tf.Variable(tf.random_normal(shape, stddev=st_dev))
    return(bias)

# Create a fully connected layer:
def fully_connected(input_layer, weights, biases):
    layer = tf.add(tf.matmul(input_layer, weights), biases)
    return layer

def npdots(A):
    n=np.array(A).shape[0]
    ret=A[0]
    for i in range(n-1):
        ret=np.dot(ret,A[i+1])
    return ret



def discrete(a,n=3):
    return np.floor(np.floor(np.array(a)+n/2)/n)*n


def nar(x):
    return np.array(x)


import datetime
print(datetime.datetime.now())
print("OK1")









l_rate=0.001 #leraning_rate

sess = tf.Session()
tf.reset_default_graph()
sess = tf.Session()

x_data=tf.placeholder(dtype=tf.float32,shape=[None,n_in])
y_target=tf.placeholder(dtype=tf.float32,shape=[None,n_out])

W1=init_weight(shape=[n_in,n_mid1],st_dev=0.1)
bias1=init_bias(shape=[n_mid1],st_dev=0.1)
z1=fully_connected(x_data,W1,bias1)
y1=tf.nn.relu(z1)

W2=init_weight(shape=[n_mid1,n_mid2],st_dev=0.1)
b2=init_bias(shape=[n_mid2],st_dev=0.1)
z2=fully_connected(y1,W2,b2)
y2=tf.nn.relu(z2)

if(n_mid3):
    W3=init_weight(shape=[n_mid2,n_mid3],st_dev=0.1)
    b3=init_bias(shape=[n_mid3],st_dev=0.1)
    z3=fully_connected(y2,W3,b3)
    y3=tf.nn.relu(z3)

    W4=init_weight(shape=[n_mid3,n_out],st_dev=0.1)
    b4=init_bias(shape=[n_out],st_dev=0.1)
    z4=fully_connected(y3,W4,b4)
    y_out=z4

else:
    W3=init_weight(shape=[n_mid2,n_out],st_dev=0.1)
    b3=init_bias(shape=[n_out],st_dev=0.1)
    z3=fully_connected(y2,W3,b3)
    y_out=z3


dy_t=tf.subtract(y_out,y_target)
dy_t2=tf.square(dy_t)
loss=tf.reduce_mean(dy_t2)

#ここまでで中間1層のネットワークの準備が完了

my_opt=tf.train.AdamOptimizer(learning_rate = l_rate) #「○○法で学習を行う」宣言
train_step=my_opt.minimize(loss)

init=tf.global_variables_initializer()
sess.run(init) #TensorFlow 内部を初期化



def save_tf_data(dA,step,mode):

    time_now=datetime.datetime.now()

    time_now=datetime.datetime.now()
    fn_top=outdir+"mode=[{},{},{}]_dA={}_step={}_dy={}_dz={}".format(m[0],m[1],m[2],dA,step,bat_dy,bat_dz)

    W1_=sess.run(W1)
    b1_=sess.run(bias1)
    W2_=sess.run(W2)
    b2_=sess.run(b2)
    W3_=sess.run(W3)
    b3_=sess.run(b3)
    np.save(fn_top + "_W1",W1_)
    np.save(fn_top + "_b1",b1_)
    np.save(fn_top + "_W2",W2_)
    np.save(fn_top + "_b2",b2_)
    np.save(fn_top + "_W",W3_)
    np.save(fn_top + "_b3",b3_)

    if(n_mid3):
        W4_=sess.run(W4)
        b4_=sess.run(b4)
        np.savetxt(fn_top + "_W4.txt",X=W4_)
        np.savetxt(fn_top + "_b4.txt",X=b4_)

print(datetime.datetime.now())









def calc_wave(th,ph,thel,ther,phel,pher,psel,pser,t_rand=False,Slr_mode=False):

    nb=th.size #200 #n_batch
    nT=thel.size #330
    #print("calc_wave nb,nT=",nb,nT)
    if(t_rand):ran=(2*np.random.rand()-1)*(Times[1]-Times[0])
    else: ran=0
    r=[1.0 for i in range(nb)]

    Pl=np.zeros((nT,3,3))
    Pr=np.zeros((nT,3,3))

    xyz_Ptl=np.zeros((nT,3))
    xyz_Ptr=np.zeros((nT,3))

    for ti in range(nT):
        Pl[ti]=np.dot(Rot(thel[ti],2),np.dot(Rot(-phel[ti],1),Rot(-psel[ti],0)))
        Pr[ti]=np.dot(Rot(ther[ti],2),np.dot(Rot(-pher[ti],1),Rot(-pser[ti],0))) #pselrにマイナス付加


    rtp=np.array([np.array([r[i],th[i],ph[i]]) for i in range(nb)])
    xyz=np.array([r2x_3(rtp[i]) for i in range(nb)])


    Nl=np.zeros((nb,nT,3))
    Nr=np.zeros((nb,nT,3))
    for i in range(nb):
        xyz_=xyz[i]#/np.linalg.norm(xyz[i])
        Nl[i]=np.array([np.dot(Pl[ti].T,xyz_) for ti in range(nT)])
        Nr[i]=np.array([np.dot(Pr[ti].T,xyz_) for ti in range(nT)])

    dy=bat_dy
    dz=bat_dz
    Sl=np.array([cos(pi*dy*Nl[i,:,1]/wave_l)*cos(pi*dz*Nl[i,:,2]/wave_l) for i in range(nb)])
    Sr=np.array([cos(pi*dy*Nr[i,:,1]/wave_l)*cos(pi*dz*Nr[i,:,2]/wave_l) for i in range(nb)])

    if(Slr_mode):return Sl,Sr
    dAlr=20*np.log10(np.abs(Sl[:]/Sr[:]))
    return dAlr


print(datetime.datetime.now())











print("outdir=",outdir)
psel,pser=calc_pses(times=Times)
phel,pher=calc_phes(times=Times)
thel,ther=calc_thes(times=Times)

print("phel.shape=",phel.shape)
nT=Times.size


nx_test=23
dy_ts=np.ones((out_n_step,nx_test**2,2))*np.inf
dy_ts2=np.ones((out_n_step,nx_test**2,2))*np.inf

ijks=[]
temp=[10,11,12,13,14,15]
i_s=temp
js=[14]
ks=temp


for j in js:
    for i in i_s:
        for k in ks:
            #if((i==10 and j==10) or (j==10 and k==10) or (k==10 and i==10)):continue
            ijks.append(nar([i,j,k]))
#ijks=[[11,107,107],[11,108,108],[11,15,13]]

ijks=nar(ijks)
print(ijks)

fctl=outdir+"0modeControl.txt"
f=open(fctl,"r")
try:
    fcntl.flock(f, fcntl.LOCK_UN)
    print("open")
except:
    print("OK")
f.close()


irelearn=None
jrelearn=None
krelearn=None


dAs=[1]
dAlearn=None
p_i=0
while(1):

    with open(fctl,"r+") as f:
        try:
            fcntl.flock(f, fcntl.LOCK_EX)
            n_input = f.readlines()
            p_i=int(n_input[0])
            print(f"{p_i} in {ijks.shape[0]*len(dAs)}")
            f.close()
            f=open(fctl,"w")
            f.write(str(p_i+1))
            fcntl.flock(f, fcntl.LOCK_UN)
            f.close()
        except:
            time.sleep(1)
            continue
    if(p_i>=ijks.shape[0]*len(dAs)):
        break


    dA=dAs[p_i%len(dAs)]
    print("dA=",dA)



    mode=ijks[p_i//len(dAs)]
    m=mode
    i,j,k=m
    print(f"mode={i},{j},{k}_{p_i}")

    if((not irelearn is None) and (not (i in irelearn))):continue
    if((not jrelearn is None) and (not (j in jrelearn))):continue
    if((not krelearn is None) and (not (k in krelearn))):continue
    if((not dAlearn is None) and (not (dA in dAlearn))):continue


    draw=False
    fndw=outdir + "mode=[{},{},{}]_dA={}_".format(m[0],m[1],m[2],dA)
    psel,pser=calc_pses(times=Times,mode=mode[0])
    phel,pher=calc_phes(times=Times,mode=mode[1])
    thel,ther=calc_thes(times=Times,mode=mode[2])

    #drawXY(X=Times,Y=[psel*r2d,pser*r2d],title="pses",m=-16,M=16,lw=8,fname=fndw+"psi_e.png",draw=draw)
    #drawXY(X=Times,Y=[phel*r2d,pher*r2d],title="phes",m=-16,M=16,lw=8,fname=fndw+"phi_e.png",draw=draw)
    #drawXY(X=Times,Y=[thel*r2d,ther*r2d],title="thes",m=-16,M=16,lw=8,fname=fndw+"theta_e.png",draw=draw)


    sess.run(init)
    check_OK=False
    loss_save=np.inf#1*(1e-1)
    loss_threshold=1e-4
    loss_min=np.inf
    loss_min_fin=np.inf


    dy_ts=np.ones((out_n_step,nx_test**2,2))*np.inf
    dy_ts_i=0

    fndw=outdir + "mode=[{},{},{}]_dA={}_dy={}_dz={}_out.png".format(m[0],m[1],m[2],dA,bat_dy,bat_dz)

    for step in range(max_step+1):

        nx=11
        data_n=nx*nx
        obs_r=[1.0 for i in range(data_n)]
        x=np.linspace(-search_tp+0.1*d2r,search_tp+0.1*d2r,nx)#-60,60
        randmode=True
        dx=(search_tp+0.1*d2r+search_tp+0.1*d2r)*randmode/nx
        Xc=np.array([[x[i]+(np.random.rand()-0.5)*dx,x[j]+(np.random.rand()-0.5)*dx] for i in range(nx) for j in range(nx)])
        obs_tp=Xc

        obs_rtp=np.array([np.array([obs_r[i],obs_tp[i,0],obs_tp[i,1]]) for i in range(data_n)])
        obs_xyz=np.array([r2x_3(obs_rtp[i]) for i in range(data_n)])

        dAlr_n=calc_wave(th=obs_rtp[:,1],ph=obs_rtp[:,2],thel=thel,phel=phel,ther=ther,pher=pher,psel=psel,pser=pser)
        if(dA):dAlr_n=discrete(a=dAlr_n,n=dA)

        TPind=np.arange(obs_tp.shape[0])
        np.random.shuffle(TPind)
        #print("TPind",TPind)

        n_iter=nx
        batch_size=int(data_n/n_iter+0.1)
        for batch in range(n_iter):
            i0=int(batch_size*batch+0.1)
            i1=int(i0+batch_size+0.1)

            sess.run(train_step,feed_dict={x_data:dAlr_n[TPind[i0:i1]],y_target:obs_tp[TPind[i0:i1]]})


        if(step%100==0):print("step=",step,datetime.datetime.now())
        if(step%50==0):

            nx=nx_test
            data_n=nx*nx
            obs_r=[obs_rRange[0]+np.random.rand()*(obs_rRange[1]-obs_rRange[0]) for i in range(data_n)]
            x=np.linspace(-search_tp,search_tp,nx)#-60,60
            randmode=False
            dx=2*(search_tp)*randmode/nx
            Xc=np.array([[x[i]+(np.random.rand()-0.5)*dx,x[j]+(np.random.rand()-0.5)*dx] for i in range(nx) for j in range(nx)])
            obs_tp=Xc
            #drawXY(X=obs_tp[:,0],Y=obs_tp[:,1])
            obs_rtp=np.array([np.array([obs_r[i],obs_tp[i,0],obs_tp[i,1]]) for i in range(data_n)])
            obs_xyz=np.array([r2x_3(obs_rtp[i]) for i in range(data_n)])

            dAlr_n=calc_wave(th=obs_rtp[:,1],ph=obs_rtp[:,2],thel=thel,phel=phel,ther=ther,pher=pher,psel=psel,pser=pser)
            if(dA):dAlr_n=discrete(a=dAlr_n,n=dA)


            loss_value=sess.run(loss,feed_dict={x_data:dAlr_n,y_target:obs_tp})

            if(np.isnan(loss_value)):
                sess.run(tf.global_variables_initializer())
                nan_error+=1

            time_now=datetime.datetime.now()
            fn=outdir+ "mode=[{},{},{}]_dA={}_dy={}_dz={}_".format(m[0],m[1],m[2],dA,bat_dy,bat_dz)+time_now.strftime("%Y%m%d%H%M%S") + "_loss=" + str(loss_value) +"_step=" + str(step) + ".png"

            if(loss_value<loss_min):
                print("!--")
                loss_min=loss_value
                if(loss_value<loss_save):
                    time_now=datetime.datetime.now()
                    fn=outdir+ "mode=[{},{},{}]_da={}_dy={}_dz={}_".format(m[0],m[1],m[2],dA,bat_dy,bat_dz)+time_now.strftime("%Y%m%d%H%M%S") + "_loss=" + str(loss_value) +"_step=" + str(step) + "_min.png"

            elif(step%500==0):
                time_now=datetime.datetime.now()
                fn=outdir+ "mode=[{},{},{}]_dA={}_dy={}_dz={}_".format(m[0],m[1],m[2],dA,bat_dy,bat_dz)+time_now.strftime("%Y%m%d%H%M%S") + "_loss=" + str(loss_value) +"_step=" + str(step) + ".png"
                #draw_testdata(nx=41,fname=fn)


        if(step>out_step): # and loss_value<loss_min_fin):

            nx=nx_test
            data_n=nx*nx
            obs_r=[obs_rRange[0]+np.random.rand()*(obs_rRange[1]-obs_rRange[0]) for i in range(data_n)]
            x=np.linspace(-search_tp,search_tp,nx)#-60,60
            randmode=False
            dx=2*(search_tp)*randmode/nx
            Xc=np.array([[x[i]+(np.random.rand()-0.5)*dx,x[j]+(np.random.rand()-0.5)*dx] for i in range(nx) for j in range(nx)])
            obs_tp=Xc
            #drawXY(X=obs_tp[:,0],Y=obs_tp[:,1])
            obs_rtp=np.array([np.array([obs_r[i],obs_tp[i,0],obs_tp[i,1]]) for i in range(data_n)])
            obs_xyz=np.array([r2x_3(obs_rtp[i]) for i in range(data_n)])

            dAlr_n=calc_wave(th=obs_rtp[:,1],ph=obs_rtp[:,2],thel=thel,phel=phel,ther=ther,pher=pher,psel=psel,pser=pser)
            if(dA):dAlr_n=discrete(a=dAlr_n,n=dA)

            loss_value=sess.run(loss,feed_dict={x_data:dAlr_n,y_target:obs_tp})

            if(loss_value<loss_min_fin):
                loss_min_fin=loss_value
                save_tf_data(dA=dA,step=step,mode=mode)

                time_now=datetime.datetime.now()


            for sigma2_i in range(Amp_sigmas.size):

                dAlr_n=calc_wave(th=obs_rtp[:,1],ph=obs_rtp[:,2],thel=thel,phel=phel,ther=ther,pher=pher,psel=psel,pser=pser)
                if(dA):dAlr_n=discrete(a=dAlr_n,n=dA)


                dy_ts[dy_ts_i]= sess.run(y_out,feed_dict={x_data:dAlr_n,y_target:obs_tp})
                dy_ts2[dy_ts_i]= sess.run(dy_t,feed_dict={x_data:dAlr_n,y_target:obs_tp})


                fndw=outdir+ "mode=[{},{},{}]_dA={}_dy={}_dz={}_".format(m[0],m[1],m[2],dA,bat_dy,bat_dz)
                np.savetxt(fndw+"_test_y.txt",X=dy_ts[0])
                np.savetxt(fndw+"_test_t.txt",X=obs_tp)

            dy_ts_i+=1


    print("dy_ts.shape=",dy_ts.shape)
    print("dy_ts=",dy_ts)

    fndw=outdir+ "mode=[{},{},{}]_dA={}_dy={}_dz={}_".format(m[0],m[1],m[2],dA,bat_dy,bat_dz)
    np.savetxt(fndw+"_test.txt",X=dy_ts[0])
    np.save(fndw+"_dyst",dy_ts2)

print(datetime.datetime.now())
