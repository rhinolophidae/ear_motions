import numpy as np

def r2x(rtp=np.array([0.0,0.0,0.0])):
    """
    r2x(rtp=np.array([0.0,0.0,0.0]))

    import numpy as np

    rtp2xyz([r,theta,phi]) => (x,y,z) from r,theta,pi
    x=r*np.cos(t)*np.cos(p)
    y=r*np.sin(t),
    z=r*np.cos(t)*np.sin(p)
    """
    r,t,p=rtp
    return np.array([
    r*np.cos(t)*np.cos(p),
    r*np.sin(t),
    r*np.cos(t)*np.sin(p)
    ])

def r2x_2(rtp=np.array([0.0,0.0,0.0])):
    """
    r2x_2(rtp=np.array([0.0,0.0,0.0]))

    import numpy as np

    r2x_2([r,theta,phi]) => (x,y,z) from r,theta,pi
    x=r*np.cos(p)*np.cos(t),
    y=r*np.cos(p)*np.sin(t),
    z=-r*np.sin(p)
    """
    r,t,p=rtp
    return np.array([
    r*np.cos(p)*np.cos(t),
    r*np.cos(p)*np.sin(t),
    r*np.sin(-p)
    ])

def r2x_3(rtp=np.array([0.0,0.0,0.0])):
    from rot_mat import Rot
    """
    r2x_3(rtp=np.array([0.0,0.0,0.0]))

    import numpy as np

    r2x_3([r,theta,phi]) => (x,y,z) from r,theta,pi

    """

    r,t,p=rtp
    return np.dot(np.dot(Rot(t,2),Rot(-p,1)),np.array([r,0,0]))
    #phiはエレベーションとするのでマイナスがつく
