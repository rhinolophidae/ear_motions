"""
from importlib import reload
from calc_ears import calc_thes,calc_phes,calc_pses
reload(sys.modules["calc_ears"])
from calc_ears import calc_thes,calc_phes,calc_pses
"""

import numpy as np
from numpy import pi,sin,cos
d2r=pi/180


def calc_thes(times,mode=0,w=15,out=False,fname=None,f_ear=15):
    nt=times.size
    Mt=times[nt-1]
    ret=np.zeros_like(times)
    ret2=np.zeros_like(times)

    if(mode==1):
        ret=w*np.ones_like(times)
    elif(mode==2):
        ret=w*sin(2*pi*f_ear*times)
    elif(mode==3):
        ret=0.5*(w-w*sin(2*pi*f_ear*times))
    elif(mode==4):
        ret=w-w*sin(2*pi*f_ear*times)
        ret[ret>w]=w
    elif(mode==5):
        ret=w*sin(4*pi*f_ear*times)
        ret[ret>w]=w

    elif(mode==10):
        ret=ret
    elif(mode==11):
        ret=w*np.ones_like(times)
    elif(mode==12 or mode==13):
        ret=w*sin(2*pi*f_ear*times)
    elif(mode==14 or mode==15):
        ret=w*cos(2*pi*f_ear*times)

    elif(mode==20):
        ret=0.5*w*(1+sin(2*pi*f_ear*times))

    elif(mode==101):
        ret= w/2*sin(2*pi*f_ear*times)+w/2
        ret2=w/2*sin(2*pi*f_ear*(times+Mt/4))-w/2

    elif(mode==102 or mode==103):
        ret= w* cos(4*pi*f_ear*times)
        ret2=w*(-cos(4*pi*f_ear*times))

    elif(mode==104):
        ret= w* sin(4*pi*f_ear*times)
        ret2=w*sin(4*pi*f_ear*times)

    elif(mode==112):
        ret=  w*sin(4*pi*f_ear*times)
        ret2=-w*sin(4*pi*f_ear*times)
    elif(mode==113):
        ret=  w*sin(4*pi*f_ear*times)
        ret2= w*sin(4*pi*f_ear*times)
    elif(mode==114):
        ret=  w*cos(4*pi*f_ear*times)
        ret2=-w*cos(4*pi*f_ear*times)
    elif(mode==115):
        ret=  w*cos(4*pi*f_ear*times)
        ret2= w*cos(4*pi*f_ear*times)

    elif(mode==105):
        ret= w*sin(2*pi*f_ear*times)
        ret2=w*sin(2*pi*f_ear*(times+3*Mt/8))

    elif(mode==106):
        ret= w*sin(2*pi*f_ear*times)
        ret2=w*sin(2*pi*f_ear*(times+Mt/4))

    elif(mode==107):
        ret= w*sin(2*pi*f_ear*times)
        ret2=w*sin(2*pi*f_ear*(times+Mt/8))

    elif(mode==108):
        ret= w*sin(2*pi*f_ear*times)
        ret2=w*sin(2*pi*f_ear*(times+Mt/16))

    elif(mode==109):
        ret= w*sin(2*pi*f_ear*times)
        ret2=w*sin(2*pi*f_ear*(times+Mt/24))

    elif(mode==121):
        ret[:17]=w
        ret[17:34]=-w
        ret[34:51]=-w
        ret[51:]=w
        ret2[:17]=w
        ret2[17:34]=w
        ret2[34:51]=-w
        ret2[51:]=-w

    elif(mode==122):
        ret[:17]=w
        ret[17:34]=-w
        ret[34:51]=-w
        ret[51:]=w
        ret2[:17]=-w
        ret2[17:34]=w
        ret2[34:51]=w
        ret2[51:]=-w

    elif(mode==123):
        w2=w/np.sqrt(2)
        ret[:17]=w2
        ret[17:34]=-w2
        ret[34:51]=-w2
        ret[51:]=w2
        ret2[:17]=-w2
        ret2[17:34]=w2
        ret2[34:51]=w2
        ret2[51:]=-w2


    if(mode<100):
        ret2=-ret
        if(mode==13 or mode==15):
            ret2=ret

    return ret*d2r,ret2*d2r



def calc_phes(times,mode=0,w=15,out=False,fname=None,f_ear=15):

    nt=times.size
    Mt=times[nt-1]
    ret=np.zeros_like(times)
    ret2=np.zeros_like(times)

    if(mode==1):
        ret=w*np.ones_like(times)
    elif(mode==2):
        ret=w*cos(2*pi*f_ear*times)
    elif(mode==3):
        ret=0.5*(w-w*sin(2*pi*f_ear*times))
    elif(mode==4):
        ret=w-w*sin(2*pi*f_ear*times)
        ret[ret>w]=w

    elif(mode==9):
        ret=w*sin(2*pi*f_ear*times)+1e-5
        ret[ret>0]=w
        ret[ret<0]=-w


    elif(mode==10):
        ret=ret
    elif(mode==11):
        ret=w*np.ones_like(times)
    elif(mode==12 or mode==13):
        ret=w*sin(2*pi*f_ear*times)
    elif(mode==14 or mode==15):
        ret=w*cos(2*pi*f_ear*times)

    elif(mode==20):
        ret=0.5*w*(1+cos(2*pi*f_ear*times))

    elif(mode==101):
        ret= w/2*cos(2*pi*f_ear*times)+w/2
        ret2=w/2*cos(2*pi*f_ear*(times+Mt/4))-w/2

    elif(mode==102 or mode==104):
        ret= w*  cos(2*pi*f_ear*times)
        ret2=w*(-cos(2*pi*f_ear*times))

    elif(mode==103):
        ret= w*  cos(2*pi*f_ear*times)
        ret2=w*( cos(2*pi*f_ear*times))

    elif(mode==105):
        ret= w*cos(2*pi*f_ear*times)
        ret2=w*cos(2*pi*f_ear*(times+3*Mt/8))

    elif(mode==106):
        ret= w*cos(2*pi*f_ear*times)
        ret2=w*cos(2*pi*f_ear*(times+Mt/4))

    elif(mode==107):
        ret= w*cos(2*pi*f_ear*times)
        ret2=w*cos(2*pi*f_ear*(times+Mt/8))

    elif(mode==108):
        ret= w*cos(2*pi*f_ear*times)
        ret2=w*cos(2*pi*f_ear*(times+Mt/16))


    elif(mode==109):
        ret= w*cos(2*pi*f_ear*times)
        ret2=w*cos(2*pi*f_ear*(times+Mt/24))

    elif(mode==121):
        ret[:17]=w
        ret[17:34]=w
        ret[34:51]=-w
        ret[51:]=-w
        ret2[:17]=-w
        ret2[17:34]=w
        ret2[34:51]=w
        ret2[51:]=-w

    elif(mode==122):
        ret[:17]=w
        ret[17:34]=w
        ret[34:51]=-w
        ret[51:]=-w
        ret2[:17]=-w
        ret2[17:34]=-w
        ret2[34:51]=w
        ret2[51:]=w

    elif(mode==123):
        w2=w/np.sqrt(2)
        ret[:17]=w2
        ret[17:34]=w2
        ret[34:51]=-w2
        ret[51:]=-w2
        ret2[:17]=-w2
        ret2[17:34]=-w2
        ret2[34:51]=w2
        ret2[51:]=w2

    elif(mode==117):
        ret=5*np.ones_like(times)
        ret2=5*np.ones_like(times)

    elif(mode==118):
        ret=-15*np.ones_like(times)
        ret2=-20*np.ones_like(times)

    if(mode<100):
        ret2=-ret
        if(mode==13 or mode==15):
            ret2=ret

    return ret*d2r,ret2*d2r



def calc_pses(times,mode=0,w=15,out=False,fname=None,f_ear=15):

    nt=times.size
    Mt=times[nt-1]
    ret=np.zeros_like(times)
    ret2=np.zeros_like(times)

    if(mode==1):
        ret=w*np.ones_like(times)
    elif(mode==2):
        ret=w*cos(2*pi*f_ear*times)
    elif(mode==3):
        ret=0.5*(w-w*sin(2*pi*f_ear*times))
    elif(mode==4):
        ret=w-w*sin(2*pi*f_ear*times)
        ret[ret>w]=w

    elif(mode==10):
        ret=ret
    elif(mode==11):
        ret=w*np.ones_like(times)
    elif(mode==12 or mode==13):
        ret=w*sin(2*pi*f_ear*times)
    elif(mode==14 or mode==15):
        ret=w*cos(2*pi*f_ear*times)

    elif(mode==20):
        ret=w*np.ones_like(times)

    elif(101<=mode<=105):
        ret= w*sin(2*pi*f_ear*times)
        ret2=w*sin(2*pi*f_ear*times)

    if(mode<100):
        ret2=-ret
        if(mode==13 or mode==15):
            ret2=ret

    return ret*d2r,ret2*d2r
