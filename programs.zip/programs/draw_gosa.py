import numpy as np
import matplotlib.pyplot as plt
def draw_gosa2d(XYcorrect,XYdata,xX=1,xY=1,Xlab="",Ylab="",title="",fname=None,save_data=False,lw=1,xticks=None,yticks=None,out_str="./",mM_mode=1,mMxy=None):

    """
    def draw_gosa2d(XYcorrect,XYdata,xX=1,xY=1,Xlab="",Ylab="",title="",fname=None,save_data=False,lw=1,xticks=None,yticks=None,out_str="./",mM_mode=1,mx=None,Mx=None,my=None,My=None):

    --imports--
    
    import numpy as np
    import matplotlib.pyplot as plt
    
    XYcorrect, XYdata : shape=(:,2)
    mM_mode : 1=>plot def range min-max xyc
    mMxy = [min_x,Max_x,min_y,Max_y] : def range of plot (if set, mM_mode doesn't read)
    
    lw : linewidth
    
    if(fname is None):plt.show()
    else:plt.savefig(fname)
    
    if(save_data):
        np.savetxt(out_str+"_X.txt",X)
        np.savetxt(out_str+"_Y.txt",Y)

    """

    plt.rcParams["font.size"] = 20
    
    xyc=np.array(XYcorrect)
    xyd=np.array(XYdata)
    xyc[:,0]*=xX
    xyd[:,0]*=xX
    xyc[:,1]*=xY
    xyd[:,1]*=xY
    
    n,check2=xyc.shape
    nd,check2nd=xyd.shape
    if(check2!=2 or check2nd!=2 or n!=nd):
        print("check2!=2 =",check2!=2)
        print("check2nd!=2 =",check2nd!=2)
        print("n!=nd =",n!=nd,"  n=",n,"nd=",nd)
        print("error in draw_gosa2d")
        return
    
    figr=2.5
    figrx,figry=4,4
    figx=figrx*figr
    figy=figry*figr

    fig=plt.figure(figsize=(figx,figy))
    ax=fig.add_subplot(111)
    if(title):fig.suptitle(title,fontsize=24)
    if(Xlab):ax.set_xlabel(Xlab,fontsize=20)
    if(Ylab):ax.set_ylabel(Ylab,fontsize=20)

    if(not (xticks is None)): ax.set_xticks(xticks)
    if(not (yticks is None)): ax.set_yticks(yticks)
    
    if(not(mMxy is None)):
        mx,Mx,my,My=mMxy
        mx,Mx=mx*xX,Mx*xX
        my,My=my*xY,My*xY
    elif(mM_mode==1):
        mx=np.min(xyc[:,0])
        my=np.min(xyc[:,1])
        Mx=np.max(xyc[:,0])
        My=np.max(xyc[:,1])
    else:
        mx=np.min([np.min(xyc[:,0]),np.min(xyd[:,0])])
        my=np.min([np.min(xyc[:,1]),np.min(xyd[:,1])])
        Mx=np.max([np.max(xyc[:,0]),np.max(xyd[:,0])])
        My=np.max([np.max(xyc[:,1]),np.max(xyd[:,1])])
    dx=(Mx-mx)/200
    dy=(My-my)/200
    #print(mx,Mx,my,My)
    
    ax.set_xlim([mx-dx,Mx+dx])
    ax.set_ylim([my-dy,My+dy])
    
    ax.scatter(xyc[:,0],xyc[:,1])
    
    for i in range(n):
        ax.plot([xyc[i,0],xyd[i,0]],[xyc[i,1],xyd[i,1]],color="r",linestyle="-",linewidth=lw)
        
    if(fname is None):plt.show()
    else:plt.savefig(fname)
    
    if(save_data):
        np.savetxt(out_str+"_X.txt",X)
        np.savetxt(out_str+"_Y.txt",Y)

#print(draw_gosa2d.__doc__)



def draw_gosa1d(Ycorrect,Ydata,xY=1,Xlab="",Ylab="",title="",fname=None,save_data=False,lw=1,xticks=None,yticks=None,out_str="./",mM_mode=1,mMxy=None,fontsize=12):

    """
    def draw_gosa2d(Ycorrect,Ydata,Xlab="",Ylab="",title="",fname=None,save_data=False,lw=1,xticks=None,yticks=None,out_str="./",mM_mode=1,mx=None,Mx=None,my=None,My=None,fontsize=12):

    --imports--
    
    import numpy as np
    import matplotlib.pyplot as plt
    
    Ycorrect, Ydata : shape=(:,2)
    mM_mode : 1=>plot def range min-max xyc
    mMxy = [min_x,Max_x,min_y,Max_y] : def range of plot (if set, mM_mode doesn't read)
    
    lw : linewidth
    
    if(fname is None):plt.show()
    else:plt.savefig(fname)
    
    if(save_data):
        np.savetxt(out_str+"_X.txt",X)
        np.savetxt(out_str+"_Y.txt",Y)

    """

    plt.rcParams["font.size"] = fontsize
    
    yc=np.array(Ycorrect)*xY
    yd=np.array(Ydata)*xY
    """
    n,check2=yc.shape
    nd,check2nd=yd.shape
    if(check2!=1 or check2nd!=1 or n!=nd):
        print("yc.shape=",yc.shape)
        print("yd.shape=",yd.shape)
        print("check2!=1 =",check2!=1)
        print("check2nd!=1 =",check2nd!=1)
        print("n!=nd =",n!=nd,"  n=",n,"nd=",nd)
        print("error in draw_gosa2d")
        return
    """
    
    figr=2.5
    figrx,figry=4,4
    figx=figrx*figr
    figy=figry*figr

    fig=plt.figure(figsize=(figx,figy))
    ax=fig.add_subplot(111)
    if(title):fig.suptitle(title,fontsize=24)
    if(Xlab):ax.set_xlabel(Xlab,fontsize=20)
    if(Ylab):ax.set_ylabel(Ylab,fontsize=20)

    if(not (xticks is None)): ax.set_xticks(xticks)
    if(not (yticks is None)): ax.set_yticks(yticks)
    
    if(not(mMxy is None)):
        mx,Mx,my,My=mMxy
        mx,Mx=mx*xY,Mx*xY
        my,My=my*xY,My*xY
    elif(mM_mode==1):
        mx=np.min(yc)
        my=np.min(yc)
        Mx=np.max(yc)
        My=np.max(yc)
    else:
        mx=np.min([np.min(yc),np.min(yd)])
        my=np.min([np.min(yc),np.min(yd)])
        Mx=np.max([np.max(yc),np.max(yd)])
        My=np.max([np.max(yc),np.max(yd)])
    dx=(Mx-mx)/200
    dy=(My-my)/200
    #print(mx,Mx,my,My)
    
    ax.set_xlim([mx-dx,Mx+dx])
    ax.set_ylim([my-dy,My+dy])
    
    ax.scatter(yc,yc)
    
    for i in range(yc.size):
        ax.plot([yc[i],yc[i]],[yc[i],yd[i]],color="r",linestyle="-",linewidth=lw)
    if(fname is None):plt.show()
    else:plt.savefig(fname)
    
    if(save_data):
        np.savetxt(out_str+"_X.txt",X)
        np.savetxt(out_str+"_Y.txt",Y)

#print(draw_gosa2d.__doc__)
