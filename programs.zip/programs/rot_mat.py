import numpy as np


#軸ごとの回転行列定義 rotmat 3次元 3dim
def Rot(theta,xyz):#xyz:0->x,1->y,2->z
   """
   Rot(theta,xyz)
   theta:float
   xyz=0,1,2

   --imports--

   import numpy as np
   from numba import jit
   from numba import *

   """
   ret=np.zeros((3,3),dtype=np.float64)
   for i in range(3):
      ret[i,i]=np.cos(theta)
   ret[xyz,xyz]=1

   if(xyz==0):
      ret[1,2]=-np.sin(theta)
      ret[2,1]=np.sin(theta)
   elif(xyz==1):
      ret[0,2]=np.sin(theta)
      ret[2,0]=-np.sin(theta)
   elif(xyz==2):
      ret[0,1]=-np.sin(theta)
      ret[1,0]=np.sin(theta)

   return ret

def Rot2d(theta):
   """
   Rot2d(theta):
   theta:float

   --imports--

   import numpy as np
   """
   return np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])
