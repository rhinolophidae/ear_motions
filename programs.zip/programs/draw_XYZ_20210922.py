import numpy as np
import matplotlib.pyplot as plt
import time
import datetime
from mpl_toolkits.mplot3d import Axes3D

def drawXYZ(X,Y,Z,mode="naname",outdir="./",fname=None,save_data=False,mM=None,scatter=False,line20210902=True,fs=40,lfs=28):
    """
    ------------------------------
    drawXYZ(X,Y,Z,mode="naname",outdir="./",fname=None,save_data=False)

    mode: camera_from[elevation,azimuth]
          "front" =[0,0]
          "back"  =[0,180]
          "top"   =[89,180]
          "naname"=[45,135]

    mM: [minX,maxX,minY,maxY,minZ,maxZ]
    scatter: bool (draw scatter or not)
    --imports--

    import numpy as np
    import matplotlib.pyplot as plt
    import time
    import datetime
    from mpl_toolkits.mplot3d import Axes3D
    ------------------------------
    """

    X=np.array(X)
    Y=np.array(Y)
    Z=np.array(Z)
    #print("check X.shape=",X.shape)
    plt.rcParams["font.size"] = fs
    cmap=plt.get_cmap("tab10")

    time_now=datetime.datetime.now()
    if(X.ndim==1 or scatter):
        nh=1
        shape=False
    else:
        nh=X.shape[1]
        shape=True
    keta=int(np.floor(np.log10(nh-0.5))+1)
    #ax.scatter(X,Y,Z,marker="o",ms=18,color=cmap(0))
    for h in range(1):
        fig=plt.figure(figsize=(8,8))
        #fig.subplots_adjust(bottom=0.2)
        #ax=Axes3D(fig)
        ax = fig.add_subplot(111, projection='3d')
        if(mode=="naname"):ele,azi=45,135
        elif(mode=="front"):ele,azi=0,0
        elif(mode=="back"):ele,azi=0,180
        elif(mode=="top"):ele,azi=89,180
        else:ele,azi=mode[0],mode[1]
        ax.view_init(elev=ele,azim=azi)

        #ax.set_aspect('equal')

        if(not (mM is None)):
            ax.set_xlim(mM[0],mM[1])
            ax.set_ylim(mM[2],mM[3])
            ax.set_zlim(mM[4],mM[5])

        #ax.set_xlabel(r"$\psi$",fontsize=28)
        #ax.set_ylabel(r"$\varphi$",fontsize=28)
        #ax.set_zlabel(r"$\theta$",fontsize=28)

        ticks=[-15,0,15]
        fs=fs
        ax.set_xticks(ticks)
        #ax.set_xticklabels(ticks,fontsize=fs)
        ax.set_yticks(ticks)
        #ax.set_yticklabels(ticks,fontsize=fs)
        ax.set_zticks(ticks)
        #ax.set_zticklabels(ticks,fontsize=fs)
        #ticks=[]
        ax.set_xticklabels(ticks,fontsize=fs,horizontalalignment="right")
        ax.set_yticklabels(ticks,fontsize=fs)
        ax.set_zticklabels(ticks,fontsize=fs,horizontalalignment="left")

        if(line20210902):
            for ti in range(nh):
                #if(ti%1):continue
                ax.plot([X[0,ti],X[1,ti]],[Y[0,ti],Y[1,ti]],[Z[0,ti],Z[1,ti]],color="k")
                #if(ti%11):ax.plot([X[0,ti],X[1,ti]],[Y[0,ti],Y[1,ti]],[Z[0,ti],Z[1,ti]],color="k")
                #else:ax.plot([X[0,ti],X[1,ti]],[Y[0,ti],Y[1,ti]],[Z[0,ti],Z[1,ti]],color="r")

            ti=0
            #ax.plot([X[0,ti],X[1,ti]],[Y[0,ti],Y[1,ti]],[Z[0,ti],Z[1,ti]],color="g",linewidth=4)

        for i in range(X.shape[0]): ax.plot(X[i],Y[i],Z[i],color=cmap(i),linewidth=6)

        #plt.tight_layout()
        fig.subplots_adjust(left=0, right=1, bottom=0, top=1)

        if(fname is None):plt.show()
        else:
            out_str="_"+str(ele) +"," + str(azi) +"_" + str(h).zfill(keta) +  ".png"
            plt.savefig(outdir+fname+out_str,transparent=True)

        if(save_data):
            np.savetxt(out_str+"_X.txt",X)
            np.savetxt(out_str+"_Y.txt",Y)

        del fig
