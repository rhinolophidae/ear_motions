
Created on Thu Jan  6 15:47:03 2022

@author: Takahiro Hiraga


These programs were used for the research article entitled the
"Theoretical investigation of active listening behavior based on the echolocation of CF-FM bats."

By using three main programs as follows, you can analyse as described in that article

1: calcEvaluate.py   --evaluation with our original function can be performed. 
2: learn.py   --Supervised machine learnings can be performed.
3: drawEL.py  --drawing result glaphs

other: import files

environment.yml: environment for anaconda on this study


Necessary directories and files

output_data/
- output_LE/
-- evaluate/
--- 0modeControl.txt
-- learn/
--- 0modeControl.txt