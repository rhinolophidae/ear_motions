import numpy as np

in_dir="output_data/output_LE/learn/"

temp=[10,11,12,13,14,15]
i_s=temp
js=[14]
ks=temp

for i in i_s:
    for j in js:
        for k in ks:
            try:
                data=np.load(in_dir+f"mode=[{i},{j},{k}]_dA=0_dy=0.0024251069875891582_dz=0.0024251069875891582__dyst.npy")
                data1=np.median(data,axis=0)
                n=int(np.sqrt(data1.shape[0])+1e-6)
                data2=data1.reshape((n,n,-1))
                np.save(in_dir+f"mode=[{i},{j},{k}]_learn__dyst.npy",data2)
            except:
                continue
