"""
calcEvaluate.py,learn.py
drawEL.py
"""

import numpy as np
from numpy import pi,sin,cos
from scipy.spatial import ConvexHull
import datetime

from rot_mat import Rot,Rot2d
from rtp2xyz import r2x_3
from calc_ears import calc_thes,calc_phes,calc_pses

filename_after=""
basedir="output_data/output_LE/"
outdir=basedir+"evaluate/"

e=1e-11
r2d=180/pi #rad2deg and deg2rad
d2r=pi/180

f_emit=70100#70100
f_ear=15
c=340.0
wave_l=c/f_emit
Amp=0.25

tp_range=60.1*d2r

dy=0.5*0.999999999#[0.46]
dz=0.5*0.999999999#[0.48]#[0.2,0.5,1.0]#[0.2,0.4,0.5,0.6,0.8,1.0]

Amp_sigmas=np.array([0.0])

timeMax=1/f_ear
timeBunkatsu=66*1#300
Delta_t=timeMax/timeBunkatsu
timeRnd=np.random.rand()*Delta_t

bat_d=0.012
bat_dy=dy*wave_l
bat_dz=dz*wave_l #後で設定

Times=np.arange(0,timeMax,Delta_t)

max_epoch=2000
max_step=5000
out_step=max_step-250

n_in=Times.size
n_mid1=100
n_mid2=50
n_mid3=10
n_out=2

obs_rRange=[1.0,5.0]
search_theta=np.pi/3
search_phi=np.pi/3

obs_thetaRange=[-search_theta,search_theta]
obs_phiRange=[-search_phi,search_phi]




def nar(x):
    return np.array(x)

import datetime
print(datetime.datetime.now())
print("OK0")




#新たにcolormapを計算

def draw_testdata(nx=12,fname=None,sigma=0.0):

    batch_n=nx*nx
    obs_r=[obs_rRange[0]+np.random.rand()*(obs_rRange[1]-obs_rRange[0]) for i in range(batch_n)]
    x=np.linspace(-60*d2r,60*d2r,nx)
    randmode=False
    dx=(60*d2r+60*d2r)*randmode/nx
    Xc=np.array([[x[i],x[j]] for i in range(nx) for j in range(nx)])
    obs_tp=Xc
    Slr_n=calc_wave(th=obs_tp[:,0],ph=obs_tp[:,1],thel=thel,phel=phel,ther=ther,pher=pher,sigma=sigma)
    dAlr_n_bh=20*np.log10(np.abs(Slr_n[:,0]/Slr_n[:,1]))
    dAlr_n=dAlr_n_bh[:,0:timeBunkatsu_before_hilbert:Bun_step]
    Xd=sess.run(y_out,feed_dict={x_data:dAlr_n})

    ticks=np.array([-60,-45,-30,-15,0,15,30,45,60])
    draw_gosa2d(XYcorrect=Xc,XYdata=Xd,xticks=ticks,yticks=ticks,mMxy=[-65*d2r,65*d2r,-65*d2r,65*d2r],xX=r2d,xY=r2d,fname=fname)


def calc_wave(th,ph,thel,ther,phel,psel,pser,pher,t_rand=False,Slr_mode=False):

    nb=th.size
    nT=thel.size
    if(t_rand):ran=(2*np.random.rand()-1)*(Times[1]-Times[0])
    else: ran=0


    Pl=np.zeros((nT,3,3))
    Pr=np.zeros((nT,3,3))

    for ti in range(nT):
        Pl[ti]=np.dot(Rot(thel[ti],2),np.dot(Rot(-phel[ti],1),Rot(-psel[ti],0)))
        Pr[ti]=np.dot(Rot(ther[ti],2),np.dot(Rot(-pher[ti],1),Rot(-pser[ti],0))) #20211109 pselrにマイナス付加

    r=[1.0 for i in range(nb)]
    rtp=np.array([np.array([r[i],th[i],ph[i]]) for i in range(nb)])
    xyz=np.array([r2x_3(rtp[i]) for i in range(nb)])

    Nl=np.zeros((nb,nT,3))
    Nr=np.zeros((nb,nT,3))
    for i in range(nb):
        xyz_=xyz[i]#/np.linalg.norm(xyz[i])
        Nl[i]=np.array([np.dot(Pl[ti].T,xyz_) for ti in range(nT)])
        Nr[i]=np.array([np.dot(Pr[ti].T,xyz_) for ti in range(nT)])

    dy=bat_dy
    dz=bat_dz
    Sl=np.array([cos(pi*dy*Nl[i,:,1]/wave_l)*cos(pi*dz*Nl[i,:,2]/wave_l) for i in range(nb)])
    Sr=np.array([cos(pi*dy*Nr[i,:,1]/wave_l)*cos(pi*dz*Nr[i,:,2]/wave_l) for i in range(nb)])

    if(Slr_mode):return Sl,Sr
    dAlr=20*np.log10(np.abs(Sl[:]/Sr[:]))
    return dAlr



phthm=-20
phthM=20
phthfigsize=[3,2]








#calc_hilbert(Times,r_obs,rEs)

def d_o(t1,p1,t2,p2):
    x1=r2x_3(1.0,t1,p1)
    x2=r2x_3(1.0,t2,p2)
    return (1*np.linalg.norm(x1-x2))

def d_in(tp1,tp2,mode):
    if(mode==1):return np.min([np.abs(p1),np.abs(p2)])
    elif(mode==2):return 1/np.abs(p1)+1/np.abs(p2)
    elif(mode==3):return np.max([np.abs(p1),np.abs(p2)])
def d_A(dA1,dA2):
    return np.max(np.abs(dA1-dA2))



def cpa(a,n): #CopyArray
    return np.dot(a.reshape((-1,1)),np.ones(n).reshape((1,-1))).T



U1=None
def V_(As,Xs,nth,nph,mode,dim=3,v=0):
    global U1
    time_now=datetime.datetime.now()
    nth=ntph
    nph=ntph
    n=nth*nph #nobs

    t=Times
    nt=t.size
    ph=np.linspace(-tp_range,tp_range,nph)
    dph=ph[1]-ph[0]
    th=np.linspace(-tp_range,tp_range,nth)
    dth=th[1]-th[0]

    mode_str=[i for i in range(1000)]
    mode_str[10:16]=["0","const","sin_opp","sin","cos_opp","cos"]
    ms=mode_str

    U1=np.zeros(nth*nph,dtype=np.float16)
    U2=np.zeros(nth*nph,dtype=np.float16)

    dAa=0
    fostr=""
    for ht1 in range(nth):
        t1=th[ht1]
        for hp1 in range(nph):
            p1=ph[hp1]
            o1=hp1*nth+ht1

            A1=As[o1]
            dA=As-A1
            dAM=np.max(np.abs(As-A1),axis=1)

            dO=np.linalg.norm(Xs[o1]-Xs,axis=1)


            U1[o1]=np.max(dO/(dAM+1e-5))

    U1[U1>10000]=10000
    print("U1=",U1)

    m=mode
    fn=outdir+"mode=[{},{},{}]".format(m[0],m[1],m[2])+"_nth=nph={}".format(ntph)+ "_U1"
    U1_=U1.reshape((nth,-1))
    np.savetxt(fn+".txt",U1_)
    print(U1_[3])


def calc_waves(ntp,mode):

    psel,pser=calc_pses(times=Times,mode=mode[0])
    phel,pher=calc_phes(times=Times,mode=mode[1])
    thel,ther=calc_thes(times=Times,mode=mode[2])

    pts=[]
    for i in range(Times.size):
        pts.append([psel[i],phel[i],thel[i]])
        pts.append([pser[i],pher[i],ther[i]])
    pts=nar(pts)
    dim=np.linalg.matrix_rank(pts)
    if(dim==3):
        v=ConvexHull(pts).volume
    else:
        v=0



    fndw=outdir
    m=mode

    temp=np.linspace(-tp_range,tp_range,ntp)
    th,ph=np.meshgrid(temp,temp)
    th=th.reshape(-1)
    ph=ph.reshape(-1)

    nb=th.size #200 #n_batch
    nT=thel.size #330
    #print("calc_wave nT",nT)

    dAlr=calc_wave(th,ph,thel=thel,ther=ther,phel=phel,pher=pher,psel=psel,pser=pser)
    return dAlr,dim,v


b=[]
M=5
ntph=131#131


temp=[10,11,12,13,14,15]

i_s=temp
js=[14]
ks=temp

ijks=[]
for i in i_s:
    for j in js:
        for k in ks:
            ijks.append(nar([i,j,k]))
#ijks=[[11,107,107],[11,108,108],[11,15,13]]

ijks=nar(ijks)
p_i=0
fctl=outdir+"0modeControl.txt"



import fcntl
f=open(fctl,"r")
try:
    fcntl.flock(f, fcntl.LOCK_UN)
    print("open")
except:
    print("OK")
f.close()

while(1):

    with open(fctl,"r") as f:
        try:
            fcntl.flock(f, fcntl.LOCK_EX)
            n_input = f.readlines()
            p_i=int(n_input[0])
            print(p_i)
            f.close()
            f=open(fctl,"w")
            f.write(str(p_i+1))
            fcntl.flock(f, fcntl.LOCK_UN)
            f.close()
        except:
            time.sleep(1)
            continue
    if(p_i>=ijks.shape[0]):
        break

    mode=ijks[p_i]


    print("mode",mode)

    time_now=datetime.datetime.now()
    fn=outdir+"mode=[{},{},{}]_".format(i,j,k)+"nth=nph={}".format(ntph)+ ".txt"
    print(fn)

    As,dim,v=calc_waves(ntp=ntph,mode=mode)
    print("As.shape,v=",As.shape,dim,v)

    temp=np.linspace(-tp_range,tp_range,ntph)
    th,ph=np.meshgrid(temp,temp)
    th=th.reshape(-1)
    ph=ph.reshape(-1)
    Xs=np.array([r2x_3([1.0,th[i],ph[i]]) for i in range(th.size)])

    a=np.array([0])
    np.savetxt(fn,a)


    print("----------\nmode=",mode,V_(As=As.copy(),Xs=Xs.copy(),nth=ntph,nph=ntph,mode=mode,dim=dim,v=v))


print("OK1")
print(datetime.datetime.now())
