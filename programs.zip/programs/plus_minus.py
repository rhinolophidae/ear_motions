from numba import jit
from numba import *

@jit(i1(i2))
def pm(x):
    """
    pm(x):
    return (-1)^x
    
    --imports--
    
    from numba import jit
    import numba *
    
    """
    
    if(x%2):return -1
    else: return 1
    
